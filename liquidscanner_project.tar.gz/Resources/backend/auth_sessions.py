"""
Менеджер сессий Telegram для работы с несколькими аккаунтами
"""
import asyncio
import logging
import json
import os
from datetime import datetime
from typing import List, Dict, Optional, Any
from dataclasses import dataclass

from telethon import TelegramClient
from telethon.errors import (
    SessionPasswordNeededError,
    PhoneNumberInvalidError,
    FloodWaitError
)

logger = logging.getLogger(__name__)

@dataclass
class SessionConfig:
    """Конфигурация сессии Telegram"""
    account_id: str
    name: str
    phone: str
    api_id: int
    api_hash: str
    session_file: str
    is_active: bool = True

class TelegramSessionManager:
    """Менеджер сессий Telegram"""
    
    def __init__(self, sessions_dir: str = "sessions"):
        self.sessions_dir = sessions_dir
        self.clients: Dict[str, TelegramClient] = {}
        self.sessions: Dict[str, SessionConfig] = {}
        self.active_sessions: Dict[str, bool] = {}
        
        # Создаем директорию для сессий, если её нет
        os.makedirs(sessions_dir, exist_ok=True)
        
        # Загружаем конфигурации сессий
        self._load_session_configs()
    
    def _load_session_configs(self):
        """Загрузка конфигураций сессий из файла"""
        config_file = os.path.join(self.sessions_dir, "sessions_config.json")
        
        if os.path.exists(config_file):
            try:
                with open(config_file, 'r') as f:
                    configs = json.load(f)
                    
                for config_data in configs:
                    config = SessionConfig(**config_data)
                    self.sessions[config.account_id] = config
                    
            except Exception as e:
                logger.error(f"Ошибка загрузки конфигураций: {str(e)}")
    
    def _save_session_configs(self):
        """Сохранение конфигураций сессий в файл"""
        config_file = os.path.join(self.sessions_dir, "sessions_config.json")
        
        try:
            configs = []
            for session in self.sessions.values():
                configs.append({
                    'account_id': session.account_id,
                    'name': session.name,
                    'phone': session.phone,
                    'api_id': session.api_id,
                    'api_hash': session.api_hash,
                    'session_file': session.session_file,
                    'is_active': session.is_active
                })
            
            with open(config_file, 'w') as f:
                json.dump(configs, f, indent=2)
                
        except Exception as e:
            logger.error(f"Ошибка сохранения конфигураций: {str(e)}")
    
    async def add_session(self, config: SessionConfig):
        """Добавление новой сессии"""
        self.sessions[config.account_id] = config
        
        # Создаем клиент
        session_path = os.path.join(self.sessions_dir, config.session_file)
        client = TelegramClient(session_path, config.api_id, config.api_hash)
        
        try:
            await client.connect()
            
            if not await client.is_user_authorized():
                logger.info(f"Требуется авторизация для аккаунта {config.name}")
                # Здесь можно добавить логику запроса кода
                self.active_sessions[config.account_id] = False
            else:
                logger.info(f"Аккаунт {config.name} уже авторизован")
                self.active_sessions[config.account_id] = True
                
                self.clients[config.account_id] = client
                
        except Exception as e:
            logger.error(f"Ошибка подключения аккаунта {config.name}: {str(e)}")
            self.active_sessions[config.account_id] = False
        
        self._save_session_configs()
    
    async def authorize_session(self, account_id: str, phone_code: str = None):
        """Авторизация сессии"""
        if account_id not in self.sessions:
            raise ValueError(f"Сессия {account_id} не найдена")
        
        config = self.sessions[account_id]
        session_path = os.path.join(self.sessions_dir, config.session_file)
        
        client = TelegramClient(session_path, config.api_id, config.api_hash)
        
        try:
            await client.connect()
            
            if not await client.is_user_authorized():
                if phone_code:
                    await client.sign_in(config.phone, phone_code)
                else:
                    # Отправляем код
                    await client.send_code_request(config.phone)
                    return {"status": "code_sent", "message": "Код отправлен на телефон"}
            
            self.clients[account_id] = client
            self.active_sessions[account_id] = True
            
            logger.info(f"Аккаунт {config.name} успешно авторизован")
            return {"status": "authorized", "message": "Авторизация успешна"}
            
        except SessionPasswordNeededError:
            return {"status": "password_needed", "message": "Требуется пароль 2FA"}
        except PhoneNumberInvalidError:
            return {"status": "invalid_phone", "message": "Неверный номер телефона"}
        except FloodWaitError as e:
            return {"status": "flood_wait", "message": f"Подождите {e.seconds} секунд"}
        except Exception as e:
            logger.error(f"Ошибка авторизации: {str(e)}")
            return {"status": "error", "message": str(e)}
    
    async def scan_deposits(
        self,
        account_ids: List[str],
        uids: List[str],
        min_deposit: float = 14.0
    ) -> List[Dict[str, Any]]:
        """Сканирование депозитов для указанных аккаунтов и UID"""
        deposits = []
        
        for account_id in account_ids:
            if account_id not in self.clients or not self.active_sessions.get(account_id, False):
                logger.warning(f"Аккаунт {account_id} не активен, пропускаем")
                continue
            
            client = self.clients[account_id]
            config = self.sessions[account_id]
            
            try:
                # Здесь будет реальная логика работы с ботом @AffiliatePocketBot
                # Для демонстрации возвращаем тестовые данные
                
                for uid in uids:
                    # Имитация запроса к боту
                    deposit_data = await self._simulate_bot_request(
                        client=client,
                        uid=uid,
                        min_deposit=min_deposit
                    )
                    
                    if deposit_data:
                        deposit_data['account_id'] = account_id
                        deposit_data['account_name'] = config.name
                        deposits.append(deposit_data)
                        
            except Exception as e:
                logger.error(f"Ошибка сканирования для аккаунта {config.name}: {str(e)}")
        
        return deposits
    
    async def _simulate_bot_request(
        self,
        client: TelegramClient,
        uid: str,
        min_deposit: float
    ) -> Optional[Dict[str, Any]]:
        """Имитация запроса к боту @AffiliatePocketBot"""
        import random
        
        # С вероятностью 50% возвращаем депозит
        if random.random() > 0.5:
            amount = random.uniform(min_deposit, 1000)
            
            return {
                'uid': uid,
                'amount': round(amount, 2),
                'currency': 'USD',
                'timestamp': datetime.now().isoformat(),
                'country': random.choice(['Russia', 'Nigeria', 'USA', 'China', 'India']),
                'commission': round(amount * 0.02, 2),
                'deposit_count': random.randint(1, 5)
            }
        
        return None
    
    async def get_account_info(self, account_id: str) -> Optional[Dict[str, Any]]:
        """Получение информации об аккаунте"""
        if account_id not in self.clients:
            return None
        
        client = self.clients[account_id]
        config = self.sessions[account_id]
        
        try:
            me = await client.get_me()
            
            return {
                'account_id': account_id,
                'name': config.name,
                'phone': config.phone,
                'telegram_id': me.id,
                'username': me.username,
                'first_name': me.first_name,
                'last_name': me.last_name,
                'is_active': self.active_sessions.get(account_id, False),
                'last_seen': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Ошибка получения информации об аккаунте: {str(e)}")
            return None
    
    async def close_session(self, account_id: str):
        """Закрытие сессии"""
        if account_id in self.clients:
            try:
                await self.clients[account_id].disconnect()
                del self.clients[account_id]
                self.active_sessions[account_id] = False
                logger.info(f"Сессия {account_id} закрыта")
            except Exception as e:
                logger.error(f"Ошибка закрытия сессии: {str(e)}")
    
    async def close_all_sessions(self):
        """Закрытие всех сессий"""
        for account_id in list(self.clients.keys()):
            await self.close_session(account_id)
    
    @property
    def active_session_count(self) -> int:
        """Количество активных сессий"""
        return sum(1 for active in self.active_sessions.values() if active)

# Пример использования
async def main():
    """Пример использования менеджера сессий"""
    manager = TelegramSessionManager()
    
    # Добавление тестовых аккаунтов
    test_configs = [
        SessionConfig(
            account_id="evelyn-uid",
            name="Эвелин",
            phone="+79891243575",
            api_id=38902122,
            api_hash="d2bf17a44846878618e6eb15e9cce56d",
            session_file="evelyn.session"
        ),
        SessionConfig(
            account_id="simon-uid",
            name="Саймон",
            phone="+79128072453",
            api_id=25835050,
            api_hash="854c2bc7f1c8fa0fda69e171e356b6b2",
            session_file="simon.session"
        ),
        SessionConfig(
            account_id="fadi-uid",
            name="Фади",
            phone="+79878547363",
            api_id=34438704,
            api_hash="fc6277c6c44927f132a16fd9f86d3cc6",
            session_file="fadi.session"
        )
    ]
    
    for config in test_configs:
        await manager.add_session(config)
    
    # Получение информации об аккаунтах
    for account_id in manager.sessions.keys():
        info = await manager.get_account_info(account_id)
        if info:
            print(f"Информация об аккаунте: {info}")
    
    # Закрытие всех сессий
    await manager.close_all_sessions()

if __name__ == "__main__":
    asyncio.run(main())
