"""
FastAPI сервер для Telegram Deposit Scanner
"""
import asyncio
import json
import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field
import pandas as pd

from auth_sessions import TelegramSessionManager

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Модели данных
class Account(BaseModel):
    id: str
    name: str
    phone: str
    api_id: str
    api_hash: str
    is_active: bool = True
    last_seen: Optional[str] = None

class Deposit(BaseModel):
    uid: str
    amount: float
    currency: str = "USD"
    timestamp: str
    country: Optional[str] = None
    account_id: str
    account_name: Optional[str] = None

class ScanRequest(BaseModel):
    account_ids: List[str]
    uids: List[str] = Field(..., min_items=1)
    min_deposit: float = 14.0
    mode: str = "simulation"  # simulation, python, api

class ScanResponse(BaseModel):
    success: bool
    deposits: List[Deposit]
    stats: Dict[str, Any]
    error: Optional[str] = None

class ScanTask(BaseModel):
    id: str
    status: str  # pending, running, completed, failed
    progress: float = 0.0
    result: Optional[ScanResponse] = None

class ExportRequest(BaseModel):
    deposits: List[Deposit]
    format: str = "csv"  # csv, json, excel

# Глобальные переменные
session_manager: Optional[TelegramSessionManager] = None
scan_tasks: Dict[str, ScanTask] = {}

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Управление жизненным циклом приложения"""
    global session_manager
    
    # Запуск
    logger.info("Запуск FastAPI сервера...")
    session_manager = TelegramSessionManager()
    
    yield
    
    # Остановка
    logger.info("Остановка FastAPI сервера...")
    if session_manager:
        await session_manager.close_all_sessions()

# Создание приложения FastAPI
app = FastAPI(
    title="Telegram Deposit Scanner API",
    version="1.0.0",
    description="API для сканирования депозитов через Telegram",
    lifespan=lifespan
)

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # В продакшене указать конкретные домены
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Тестовые данные
test_accounts = [
    Account(
        id="evelyn-uid",
        name="Эвелин",
        phone="+79891243575",
        api_id="38902122",
        api_hash="d2bf17a44846878618e6eb15e9cce56d",
        is_active=True,
        last_seen=datetime.now().isoformat()
    ),
    Account(
        id="simon-uid",
        name="Саймон",
        phone="+79128072453",
        api_id="25835050",
        api_hash="854c2bc7f1c8fa0fda69e171e356b6b2",
        is_active=True,
        last_seen=datetime.now().isoformat()
    ),
    Account(
        id="fadi-uid",
        name="Фади",
        phone="+79878547363",
        api_id="34438704",
        api_hash="fc6277c6c44927f132a16fd9f86d3cc6",
        is_active=True,
        last_seen=datetime.now().isoformat()
    )
]

# Эндпоинты
@app.get("/")
async def root():
    """Корневой эндпоинт"""
    return {
        "service": "Telegram Deposit Scanner API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "accounts": "/accounts",
            "scan": "/scan",
            "scan_async": "/scan/async",
            "task_status": "/task/{task_id}",
            "export": "/export",
            "health": "/health"
        }
    }

@app.get("/health")
async def health_check():
    """Проверка здоровья сервера"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "active_sessions": session_manager.active_session_count if session_manager else 0
    }

@app.get("/accounts", response_model=List[Account])
async def get_accounts(active_only: bool = False):
    """Получить список аккаунтов"""
    if active_only:
        return [acc for acc in test_accounts if acc.is_active]
    return test_accounts

@app.post("/scan", response_model=ScanResponse)
async def scan_deposits(request: ScanRequest):
    """Синхронное сканирование депозитов"""
    try:
        logger.info(f"Начало сканирования для {len(request.uids)} UID")
        
        deposits = []
        
        if request.mode == "simulation":
            # Режим симуляции
            deposits = await simulate_scan(request)
        elif request.mode == "python":
            # Режим Python (через Telethon)
            if not session_manager:
                raise HTTPException(status_code=500, detail="Session manager not initialized")
            
            deposits = await session_manager.scan_deposits(
                account_ids=request.account_ids,
                uids=request.uids,
                min_deposit=request.min_deposit
            )
        else:
            raise HTTPException(status_code=400, detail=f"Unknown mode: {request.mode}")
        
        # Статистика
        stats = {
            "total_deposits": len(deposits),
            "total_amount": sum(d.amount for d in deposits),
            "average_amount": sum(d.amount for d in deposits) / len(deposits) if deposits else 0,
            "countries": {},
            "accounts": {}
        }
        
        for deposit in deposits:
            # Статистика по странам
            country = deposit.country or "Unknown"
            stats["countries"][country] = stats["countries"].get(country, 0) + 1
            
            # Статистика по аккаунтам
            account_id = deposit.account_id
            stats["accounts"][account_id] = stats["accounts"].get(account_id, 0) + 1
        
        return ScanResponse(
            success=True,
            deposits=deposits,
            stats=stats
        )
        
    except Exception as e:
        logger.error(f"Ошибка сканирования: {str(e)}")
        return ScanResponse(
            success=False,
            deposits=[],
            stats={},
            error=str(e)
        )

@app.post("/scan/async")
async def scan_deposits_async(request: ScanRequest, background_tasks: BackgroundTasks):
    """Асинхронное сканирование депозитов"""
    import uuid
    
    task_id = str(uuid.uuid4())
    
    # Создаем задачу
    task = ScanTask(
        id=task_id,
        status="pending"
    )
    scan_tasks[task_id] = task
    
    # Запускаем в фоне
    background_tasks.add_task(
        execute_scan_task,
        task_id=task_id,
        request=request
    )
    
    return {"task_id": task_id, "status": "started"}

@app.get("/task/{task_id}")
async def get_task_status(task_id: str):
    """Получить статус задачи"""
    if task_id not in scan_tasks:
        raise HTTPException(status_code=404, detail="Task not found")
    
    return scan_tasks[task_id]

@app.post("/export")
async def export_deposits(request: ExportRequest):
    """Экспорт депозитов в файл"""
    try:
        if request.format == "csv":
            # Экспорт в CSV
            df = pd.DataFrame([d.dict() for d in request.deposits])
            csv_content = df.to_csv(index=False)
            
            return JSONResponse({
                "success": True,
                "format": "csv",
                "content": csv_content,
                "filename": f"deposits_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            })
            
        elif request.format == "json":
            # Экспорт в JSON
            json_content = json.dumps(
                [d.dict() for d in request.deposits],
                indent=2,
                ensure_ascii=False
            )
            
            return JSONResponse({
                "success": True,
                "format": "json",
                "content": json_content,
                "filename": f"deposits_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            })
            
        elif request.format == "excel":
            # Экспорт в Excel
            df = pd.DataFrame([d.dict() for d in request.deposits])
            excel_path = f"/tmp/deposits_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            df.to_excel(excel_path, index=False)
            
            return FileResponse(
                excel_path,
                filename=f"deposits_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
            
        else:
            raise HTTPException(status_code=400, detail=f"Unsupported format: {request.format}")
            
    except Exception as e:
        logger.error(f"Ошибка экспорта: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/logs")
async def get_logs(limit: int = 100, level: Optional[str] = None):
    """Получить логи сервера"""
    # В реальном приложении здесь будет чтение из файла логов
    return {
        "logs": [
            {
                "timestamp": datetime.now().isoformat(),
                "level": "INFO",
                "message": "Логирование будет реализовано в следующих версиях"
            }
        ]
    }

# Вспомогательные функции
async def simulate_scan(request: ScanRequest) -> List[Deposit]:
    """Симуляция сканирования депозитов"""
    import random
    
    deposits = []
    
    for uid in request.uids:
        for account_id in request.account_ids:
            # Находим аккаунт
            account = next((acc for acc in test_accounts if acc.id == account_id), None)
            if not account or not account.is_active:
                continue
            
            # Случайным образом определяем, есть ли депозит
            if random.random() > 0.4:  # 60% вероятность
                amount = random.uniform(20, 1000)
                
                if amount >= request.min_deposit:
                    deposit = Deposit(
                        uid=uid,
                        amount=round(amount, 2),
                        currency="USD",
                        timestamp=datetime.now().isoformat(),
                        country=random.choice(["Russia", "Nigeria", "USA", "China", "India", "Brazil", "Germany"]),
                        account_id=account_id,
                        account_name=account.name
                    )
                    deposits.append(deposit)
    
    # Сортируем по сумме (по убыванию)
    deposits.sort(key=lambda x: x.amount, reverse=True)
    
    return deposits

async def execute_scan_task(task_id: str, request: ScanRequest):
    """Выполнение задачи сканирования в фоне"""
    try:
        scan_tasks[task_id].status = "running"
        
        # Имитация прогресса
        for i in range(5):
            await asyncio.sleep(1)
            scan_tasks[task_id].progress = (i + 1) * 20
        
        # Выполнение сканирования
        response = await scan_deposits(request)
        
        scan_tasks[task_id].status = "completed"
        scan_tasks[task_id].result = response
        scan_tasks[task_id].progress = 100.0
        
    except Exception as e:
        logger.error(f"Ошибка выполнения задачи {task_id}: {str(e)}")
        scan_tasks[task_id].status = "failed"
        scan_tasks[task_id].result = ScanResponse(
            success=False,
            deposits=[],
            stats={},
            error=str(e)
        )

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
