import SwiftUI

struct ScannerView: View {
    @ObservedObject var appState: AppState
    @State private var showingSettings = false
    @State private var showingUIDsEditor = false
    @State private var progressAnimation = 0.0
    
    var activeAccountsCount: Int {
        appState.accounts.filter { $0.isEnabled }.count
    }
    
    var estimatedTime: String {
        let totalUIDs = appState.settings.customUIDs.count
        let delay = appState.settings.delayBetweenRequests
        let estimatedSeconds = Double(totalUIDs * activeAccountsCount) * delay
        return formatTimeInterval(estimatedSeconds)
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ProgressCardView(appState: appState, progressAnimation: $progressAnimation)
                
                LiveStatsView(appState: appState)
                
                ControlPanelView(
                    appState: appState,
                    showingSettings: $showingSettings,
                    showingUIDsEditor: $showingUIDsEditor
                )
                
                QuickSettingsView(appState: appState, estimatedTime: estimatedTime)
            }
            .padding()
        }
        .onChange(of: appState.scanProgress) { newValue in
            withAnimation(.easeInOut(duration: 0.5)) {
                progressAnimation = newValue
            }
        }
        .sheet(isPresented: $showingSettings) {
            ScannerSettingsView(appState: appState)
        }
        .sheet(isPresented: $showingUIDsEditor) {
            UIDsEditorView(appState: appState)
        }
    }
}

struct ProgressCardView: View {
    @ObservedObject var appState: AppState
    @Binding var progressAnimation: Double
    
    var body: some View {
        VStack(spacing: 20) {
            ZStack {
                Circle()
                    .stroke(Color.gray.opacity(0.2), lineWidth: 12)
                    .frame(width: 180, height: 180)
                
                Circle()
                    .trim(from: 0, to: progressAnimation / 100)
                    .stroke(progressGradient, style: StrokeStyle(lineWidth: 12, lineCap: .round))
                    .frame(width: 180, height: 180)
                    .rotationEffect(.degrees(-90))
                
                VStack {
                    Text("\(Int(progressAnimation))%")
                        .font(.system(size: 36, weight: .bold))
                    
                    if appState.isScanning {
                        Text("Сканирование...")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    } else {
                        Text("Готов")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text("Прогресс")
                        .font(.headline)
                    
                    Spacer()
                    
                    Text("\(Int(progressAnimation))%")
                        .font(.system(.body, design: .monospaced))
                        .fontWeight(.medium)
                }
                
                ProgressView(value: progressAnimation, total: 100)
                    .progressViewStyle(LinearProgressViewStyle())
                    .tint(progressAnimation >= 100 ? .green : .blue)
            }
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(20)
    }
    
    private var progressGradient: AngularGradient {
        AngularGradient(
            gradient: Gradient(colors: [.blue, .purple, .pink]),
            center: .center,
            startAngle: .degrees(0),
            endAngle: .degrees(360 * progressAnimation / 100)
        )
    }
}

struct LiveStatsView: View {
    @ObservedObject var appState: AppState
    
    var body: some View {
        HStack(spacing: 16) {
            LiveStatCard(
                icon: "clock.fill",
                title: "Время работы",
                value: formatTimeInterval(appState.stats.elapsedTime),
                color: .orange,
                trend: .neutral
            )
            
            LiveStatCard(
                icon: "number.circle.fill",
                title: "Проверено UID",
                value: "\(appState.stats.totalScanned)",
                color: .blue,
                trend: .neutral
            )
            
            LiveStatCard(
                icon: "dollarsign.circle.fill",
                title: "Найдено депозитов",
                value: "\(appState.stats.totalFound)",
                color: .green,
                trend: .neutral
            )
            
            LiveStatCard(
                icon: "chart.bar.fill",
                title: "Общая сумма",
                value: appState.stats.formattedTotalAmount,
                color: .purple,
                trend: .neutral
            )
        }
        .padding(.horizontal, 16)
    }
}

struct LiveStatCard: View {
    let icon: String
    let title: String
    let value: String
    let color: Color
    let trend: Trend
    
    enum Trend {
        case up, down, neutral
    }
    
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
                .frame(width: 40)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text(value)
                    .font(.title3)
                    .fontWeight(.bold)
            }
            
            Spacer()
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(12)
        .frame(minWidth: 180)
    }
}

struct ControlPanelView: View {
    @ObservedObject var appState: AppState
    @Binding var showingSettings: Bool
    @Binding var showingUIDsEditor: Bool
    
    var activeAccountsCount: Int {
        appState.accounts.filter { $0.isEnabled }.count
    }
    
    var body: some View {
        VStack(spacing: 16) {
            HStack(spacing: 12) {
                if appState.isScanning {
                    Button(action: appState.stopScanning) {
                        Label("Остановить", systemImage: "stop.circle.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                    .controlSize(.large)
                } else {
                    Button(action: appState.startScanning) {
                        Label("Начать сканирование", systemImage: "play.circle.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .disabled(activeAccountsCount == 0)
                }
                
                Button(action: {}) {
                    Label("Результаты", systemImage: "list.bullet")
                }
                .buttonStyle(.bordered)
                .disabled(appState.deposits.isEmpty)
            }
            
            HStack {
                Button(action: { showingSettings = true }) {
                    Label("Настройки", systemImage: "gear")
                }
                
                Button(action: { showingUIDsEditor = true }) {
                    Label("UID списки", systemImage: "list.number")
                }
                
                Spacer()
                
                Button(action: appState.exportToCSV) {
                    Label("Экспорт", systemImage: "square.and.arrow.up")
                }
                .disabled(appState.deposits.isEmpty)
            }
            .buttonStyle(.bordered)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(16)
    }
}

struct QuickSettingsView: View {
    @ObservedObject var appState: AppState
    let estimatedTime: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Быстрые настройки")
                .font(.headline)
            
            VStack(alignment: .leading, spacing: 12) {
                HStack {
                    Text("Мин. депозит:")
                        .foregroundColor(.secondary)
                    Spacer()
                    Text("$\(Int(appState.settings.minDepositAmount))")
                        .font(.system(.body, design: .monospaced))
                }
                
                HStack {
                    Text("Задержка:")
                        .foregroundColor(.secondary)
                    Spacer()
                    Text("\(appState.settings.delayBetweenRequests, specifier: "%.1f") сек")
                        .font(.system(.body, design: .monospaced))
                }
                
                HStack {
                    Text("Автоэкспорт:")
                        .foregroundColor(.secondary)
                    Spacer()
                    Toggle("", isOn: $appState.settings.autoExport)
                        .toggleStyle(SwitchToggleStyle())
                        .labelsHidden()
                }
                
                HStack {
                    Text("Ожидаемое время:")
                        .foregroundColor(.secondary)
                    Spacer()
                    Text(estimatedTime)
                        .font(.system(.body, design: .monospaced))
                }
            }
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(16)
    }
}

struct ScannerSettingsView: View {
    @ObservedObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            Form {
                Section("Режим работы") {
                    Picker("Режим", selection: $appState.settings.mode) {
                        ForEach(ScanSettings.ScanMode.allCases, id: \.self) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                }
                
                Section("Параметры сканирования") {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Минимальный депозит")
                            Spacer()
                            TextField("", value: $appState.settings.minDepositAmount, format: .number)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .frame(width: 100)
                            Text("USD")
                        }
                        
                        HStack {
                            Text("Задержка")
                            Spacer()
                            TextField("", value: $appState.settings.delayBetweenRequests, format: .number)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .frame(width: 100)
                            Text("секунд")
                        }
                    }
                }
                
                Section("Экспорт") {
                    Toggle("Автоматический экспорт после сканирования", isOn: $appState.settings.autoExport)
                }
            }
            .navigationTitle("Настройки сканирования")
            .frame(width: 500, height: 400)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") { dismiss() }
                }
            }
        }
    }
}

struct UIDsEditorView: View {
    @ObservedObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    
    @State private var textInput = ""
    
    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                Text("Введите UID для сканирования:")
                    .font(.headline)
                
                TextEditor(text: $textInput)
                    .font(.system(.body, design: .monospaced))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .overlay(
                        RoundedRectangle(cornerRadius: 8)
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                    )
                
                HStack {
                    Text("UID: \(uidCount)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Spacer()
                    
                    Button("Очистить") {
                        textInput = ""
                    }
                }
            }
            .padding()
            .navigationTitle("Редактор UID")
            .frame(width: 600, height: 500)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("Сохранить") {
                        saveUIDs()
                        dismiss()
                    }
                }
            }
            .onAppear {
                textInput = appState.settings.customUIDs.joined(separator: "\n")
            }
        }
    }
    
    private var uidCount: Int {
        textInput.split(separator: "\n").count
    }
    
    private func saveUIDs() {
        let uids = textInput.split(separator: "\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        appState.settings.customUIDs = uids
        appState.addPythonOutput("Обновлен список UID: \(uids.count) шт", type: .success)
    }
}

