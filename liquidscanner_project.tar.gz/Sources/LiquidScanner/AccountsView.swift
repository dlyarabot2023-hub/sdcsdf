// ... (начало файла до AddAccountView)

struct AddAccountView: View {
    @ObservedObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    
    @State private var name = ""
    @State private var phone = ""
    @State private var apiId = ""
    @State private var apiHash = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Основная информация")) {
                    TextField("Имя аккаунта", text: $name)
                    TextField("Номер телефона", text: $phone)
                }
                
                Section(header: Text("API данные Telegram")) {
                    TextField("API ID", text: $apiId)
                    TextField("API Hash", text: $apiHash)
                }
            }
            // Заменяем .formStyle(.grouped) на совместимый стиль
            .padding()
            .navigationTitle("Новый аккаунт")
            .frame(width: 400, height: 300)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .confirmationAction) {
                    Button("Добавить") {
                        let newAccount = TelegramAccount(
                            name: name,
                            phone: phone,
                            apiId: apiId,
                            apiHash: apiHash,
                            isEnabled: true,
                            sessionFile: "\(name.lowercased()).session",
                            uidsFile: "\(name)_uids.txt",
                            status: .ready
                        )
                        appState.accounts.append(newAccount)
                        appState.addPythonOutput("✅ Добавлен аккаунт: \(name)", type: .success)
                        dismiss()
                    }
                    .disabled(!isFormValid)
                }
            }
        }
    }
    
    private var isFormValid: Bool {
        !name.isEmpty &&
        !phone.isEmpty &&
        !apiId.isEmpty &&
        !apiHash.isEmpty
    }
}
