import Foundation
import Combine

class TelegramService: ObservableObject {
    @Published var isAuthenticated: Bool = false
    @Published var authError: String?
    @Published var sessionStatus: [UUID: Bool] = [:]
    
    private let pythonService: PythonService
    private var sessionsDirectory: URL {
        let appSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let dir = appSupport.appendingPathComponent("TelegramLiquidScanner/Sessions")
        
        if !FileManager.default.fileExists(atPath: dir.path) {
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
        
        return dir
    }
    
    init(pythonService: PythonService) {
        self.pythonService = pythonService
        loadSessionStatus()
    }
    
    func authenticateAccount(_ account: TelegramAccount, completion: @escaping (Result<Bool, Error>) -> Void) {
        let authScript = """
import asyncio
import os
import sys
from telethon import TelegramClient
from telethon.errors import SessionPasswordNeededError

async def authenticate():
    phone = "\(account.phoneNumber)"
    api_id = \(account.apiID)
    api_hash = "\(account.apiHash)"
    
    session_name = "\(account.id.uuidString)"
    
    client = TelegramClient(session_name, api_id, api_hash)
    
    try:
        await client.connect()
        
        if not await client.is_user_authorized():
            print("Отправка кода на номер: " + phone)
            
            # В реальном приложении здесь нужно запросить код у пользователя
            # Для демонстрации используем фиксированный код
            raise Exception("Требуется код аутентификации")
        else:
            print("Уже авторизован")
            return True
            
    except Exception as e:
        print("Ошибка аутентификации: " + str(e))
        return False
    finally:
        await client.disconnect()

if __name__ == "__main__":
    asyncio.run(authenticate())
"""
        
        let tempDir = FileManager.default.temporaryDirectory
        let scriptURL = tempDir.appendingPathComponent("auth_\(account.id.uuidString).py")
        
        do {
            try authScript.write(to: scriptURL, atomically: true, encoding: .utf8)
            
            pythonService.runScript(at: scriptURL.path) { [weak self] output, error in
                if let error = error {
                    completion(.failure(error))
                } else if output.contains("Уже авторизован") || output.contains("авторизации") {
                    DispatchQueue.main.async {
                        self?.sessionStatus[account.id] = true
                        self?.saveSessionStatus()
                        self?.isAuthenticated = true
                    }
                    completion(.success(true))
                } else {
                    completion(.failure(NSError(domain: "TelegramService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Ошибка аутентификации"])))
                }
            }
        } catch {
            completion(.failure(error))
        }
    }
    
    func scanDeposits(for account: TelegramAccount, uids: [String], minDeposit: Double) -> AnyPublisher<[Deposit], Error> {
        return Future<[Deposit], Error> { promise in
            let scanScript = self.createScanScript(account: account, uids: uids, minDeposit: minDeposit)
            
            let tempDir = FileManager.default.temporaryDirectory
            let scriptURL = tempDir.appendingPathComponent("scan_\(account.id.uuidString).py")
            
            do {
                try scanScript.write(to: scriptURL, atomically: true, encoding: .utf8)
                
                self.pythonService.runScript(at: scriptURL.path) { output, error in
                    if let error = error {
                        promise(.failure(error))
                        return
                    }
                    
                    let deposits = self.parseScanOutput(output, accountID: account.id, accountName: account.name)
                    promise(.success(deposits))
                }
            } catch {
                promise(.failure(error))
            }
        }
        .eraseToAnyPublisher()
    }
    
    private func createScanScript(account: TelegramAccount, uids: [String], minDeposit: Double) -> String {
        return """
import asyncio
import re
from telethon import TelegramClient

async def scan_deposits():
    phone = "\(account.phoneNumber)"
    api_id = \(account.apiID)
    api_hash = "\(account.apiHash)"
    min_deposit = \(minDeposit)
    
    uids = \(uids)
    
    client = TelegramClient("\(account.id.uuidString)", api_id, api_hash)
    
    try:
        await client.connect()
        
        if not await client.is_user_authorized():
            print("ОШИБКА: Пользователь не авторизован")
            return []
        
        deposits = []
        
        # Имитация работы с ботом @AffiliatePocketBot
        for uid in uids:
            print(f"Сканирование UID: {uid}")
            
            # В реальном приложении здесь будет отправка сообщения боту
            # и парсинг ответа
            # Для демонстрации генерируем фиктивные данные
            
            import random
            from datetime import datetime
            
            if random.random() > 0.3:  # 70% вероятность найти депозит
                amount = round(random.uniform(20, 1000), 2)
                
                if amount >= min_deposit:
                    deposit_data = {
                        'uid': uid,
                        'amount': amount,
                        'currency': 'USD',
                        'timestamp': datetime.now().isoformat(),
                        'country': random.choice(['Russia', 'Nigeria', 'USA', 'China', 'India']),
                        'account_id': '\(account.id.uuidString)'
                    }
                    
                    # Имитация формата ответа бота
                    print(f"UID: {uid}")
                    print(f"Sum of deposits: ${amount}")
                    print(f"Count of deposits: 1")
                    print(f"Commission: ${round(amount * 0.02, 2)}")
                    print(f"Country: {deposit_data['country']}")
                    print("---")
                    
                    deposits.append(deposit_data)
            else:
                print(f"По UID {uid} депозиты не найдены")
        
        print(f"\\nНайдено депозитов: {len(deposits)}")
        
        return deposits
        
    except Exception as e:
        print(f"ОШИБКА при сканировании: {str(e)}")
        return []
    finally:
        await client.disconnect()

if __name__ == "__main__":
    deposits = asyncio.run(scan_deposits())
    
    # Вывод в формате JSON для парсинга Swift
    import json
    print("JSON_START")
    print(json.dumps(deposits, indent=2))
    print("JSON_END")
"""
    }
    
    private func parseScanOutput(_ output: String, accountID: UUID, accountName: String) -> [Deposit] {
        var deposits: [Deposit] = []
        
        // Парсинг формата ответа бота
        let lines = output.components(separatedBy: "\n")
        var currentUID: String?
        var currentAmount: Double?
        var currentCountry: String?
        
        for line in lines {
            if line.hasPrefix("UID: ") {
                currentUID = line.replacingOccurrences(of: "UID: ", with: "").trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("Sum of deposits: $") {
                let amountString = line.replacingOccurrences(of: "Sum of deposits: $", with: "").trimmingCharacters(in: .whitespaces)
                currentAmount = Double(amountString)
            } else if line.hasPrefix("Country: ") {
                currentCountry = line.replacingOccurrences(of: "Country: ", with: "").trimmingCharacters(in: .whitespaces)
                
                if let uid = currentUID, let amount = currentAmount {
                    let deposit = Deposit(
                        id: UUID(),
                        uid: uid,
                        amount: amount,
                        currency: "USD",
                        date: Date(),
                        country: currentCountry ?? "",
                        accountID: accountID,
                        accountName: accountName
                    )
                    deposits.append(deposit)
                    
                    // Сброс для следующего депозита
                    currentUID = nil
                    currentAmount = nil
                    currentCountry = nil
                }
            }
        }
        
        // Также пытаемся парсить JSON вывод
        if let jsonStart = output.range(of: "JSON_START\n"),
           let jsonEnd = output.range(of: "\nJSON_END") {
            let jsonString = String(output[jsonStart.upperBound..<jsonEnd.lowerBound])
            
            if let jsonData = jsonString.data(using: .utf8) {
                do {
                    let jsonDeposits = try JSONDecoder().decode([JSONDeposit].self, from: jsonData)
                    
                    for jsonDeposit in jsonDeposits {
                        let deposit = Deposit(
                            id: UUID(),
                            uid: jsonDeposit.uid,
                            amount: jsonDeposit.amount,
                            currency: jsonDeposit.currency,
                            date: ISO8601DateFormatter().date(from: jsonDeposit.timestamp) ?? Date(),
                            country: jsonDeposit.country,
                            accountID: UUID(uuidString: jsonDeposit.account_id) ?? accountID,
                            accountName: accountName
                        )
                        deposits.append(deposit)
                    }
                } catch {
                    print("Ошибка парсинга JSON: \(error)")
                }
            }
        }
        
        return deposits
    }
    
    private func loadSessionStatus() {
        let fileURL = sessionsDirectory.appendingPathComponent("session_status.json")
        
        guard FileManager.default.fileExists(atPath: fileURL.path),
              let data = try? Data(contentsOf: fileURL),
              let status = try? JSONDecoder().decode([String: Bool].self, from: data) else {
            return
        }
        
        sessionStatus = status.mapKeys { UUID(uuidString: $0) ?? UUID() }
        
        // Проверяем, есть ли хотя бы одна активная сессия
        isAuthenticated = sessionStatus.values.contains(true)
    }
    
    private func saveSessionStatus() {
        let stringStatus = sessionStatus.mapKeys { $0.uuidString }
        let fileURL = sessionsDirectory.appendingPathComponent("session_status.json")
        
        do {
            let data = try JSONEncoder().encode(stringStatus)
            try data.write(to: fileURL)
        } catch {
            print("Ошибка сохранения статуса сессий: \(error)")
        }
    }
    
    func cleanupSessions() {
        do {
            let files = try FileManager.default.contentsOfDirectory(at: sessionsDirectory, includingPropertiesForKeys: nil)
            
            for file in files {
                // Удаляем только session файлы Telethon
                if file.lastPathComponent.hasSuffix(".session") {
                    try FileManager.default.removeItem(at: file)
                }
            }
            
            // Очищаем статус
            sessionStatus.removeAll()
            saveSessionStatus()
            isAuthenticated = false
            
        } catch {
            print("Ошибка очистки сессий: \(error)")
        }
    }
    
    func getSessionFile(for accountID: UUID) -> URL? {
        let sessionFile = sessionsDirectory.appendingPathComponent("\(accountID.uuidString).session")
        return FileManager.default.fileExists(atPath: sessionFile.path) ? sessionFile : nil
    }
    
    func hasValidSession(for accountID: UUID) -> Bool {
        return sessionStatus[accountID] ?? false
    }
}

// Вспомогательные структуры
private struct JSONDeposit: Codable {
    let uid: String
    let amount: Double
    let currency: String
    let timestamp: String
    let country: String
    let account_id: String
}

// Расширение для удобного преобразования ключей словаря
private extension Dictionary {
    func mapKeys<T>(_ transform: (Key) throws -> T) rethrows -> [T: Value] {
        var result: [T: Value] = [:]
        
        for (key, value) in self {
            let newKey = try transform(key)
            result[newKey] = value
        }
        
        return result
    }
}

extension PythonService {
    func runScript(at path: String, completion: @escaping (String, Error?) -> Void) {
        guard isPythonInstalled else {
            completion("", NSError(domain: "PythonService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Python не установлен"]))
            return
        }
        
        var output = ""
        
        let task = Process()
        task.executableURL = URL(fileURLWithPath: pythonPath)
        task.arguments = [path]
        
        let outputPipe = Pipe()
        let errorPipe = Pipe()
        
        task.standardOutput = outputPipe
        task.standardError = errorPipe
        
        outputPipe.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            if let string = String(data: data, encoding: .utf8) {
                output += string
                DispatchQueue.main.async {
                    self.output.append(string)
                }
            }
        }
        
        task.terminationHandler = { _ in
            DispatchQueue.main.async {
                self.isRunning = false
                completion(output, nil)
            }
        }
        
        do {
            isRunning = true
            try task.run()
        } catch {
            completion("", error)
        }
    }
}
