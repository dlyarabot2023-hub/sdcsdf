import Foundation
import Combine

class PythonService: ObservableObject {
    @Published var isRunning: Bool = false
    @Published var output: [String] = []
    @Published var error: String?
    
    private var process: Process?
    private var outputPipe: Pipe?
    private var errorPipe: Pipe?
    
    var pythonPath: String {
        let defaultPath = "/usr/bin/python3"
        
        if FileManager.default.fileExists(atPath: defaultPath) {
            return defaultPath
        }
        
        let possiblePaths = [
            "/opt/homebrew/bin/python3",
            "/usr/local/bin/python3",
            "/usr/bin/python"
        ]
        
        for path in possiblePaths {
            if FileManager.default.fileExists(atPath: path) {
                return path
            }
        }
        
        return defaultPath
    }
    
    var isPythonInstalled: Bool {
        return FileManager.default.fileExists(atPath: pythonPath)
    }
    
    func runScript(at path: String, arguments: [String] = []) {
        guard isPythonInstalled else {
            error = "Python не установлен или не найден по пути: \(pythonPath)"
            return
        }
        
        guard FileManager.default.fileExists(atPath: path) else {
            error = "Файл скрипта не найден: \(path)"
            return
        }
        
        DispatchQueue.main.async {
            self.isRunning = true
            self.output.removeAll()
            self.error = nil
            self.output.append("Запуск Python скрипта: \(path)")
        }
        
        let process = Process()
        self.process = process
        
        process.executableURL = URL(fileURLWithPath: pythonPath)
        process.arguments = [path] + arguments
        
        let outputPipe = Pipe()
        let errorPipe = Pipe()
        self.outputPipe = outputPipe
        self.errorPipe = errorPipe
        
        process.standardOutput = outputPipe
        process.standardError = errorPipe
        
        outputPipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let data = handle.availableData
            guard !data.isEmpty, let output = String(data: data, encoding: .utf8) else { return }
            
            DispatchQueue.main.async {
                self?.output.append(contentsOf: output.components(separatedBy: "\n").filter { !$0.isEmpty })
            }
        }
        
        errorPipe.fileHandleForReading.readabilityHandler = { [weak self] handle in
            let data = handle.availableData
            guard !data.isEmpty, let errorOutput = String(data: data, encoding: .utf8) else { return }
            
            DispatchQueue.main.async {
                self?.error = errorOutput
                self?.output.append("ОШИБКА: \(errorOutput)")
            }
        }
        
        process.terminationHandler = { [weak self] _ in
            DispatchQueue.main.async {
                self?.isRunning = false
                self?.output.append("Скрипт завершил выполнение")
            }
        }
        
        do {
            try process.run()
        } catch {
            DispatchQueue.main.async {
                self.isRunning = false
                self.error = "Ошибка запуска процесса: \(error.localizedDescription)"
            }
        }
    }
    
    func stopScript() {
        process?.terminate()
        isRunning = false
        output.append("Скрипт остановлен пользователем")
    }
    
    func installRequirements(at path: String) -> Bool {
        guard isPythonInstalled else {
            error = "Python не установлен"
            return false
        }
        
        let requirementsFile = URL(fileURLWithPath: path).appendingPathComponent("requirements.txt")
        
        guard FileManager.default.fileExists(atPath: requirementsFile.path) else {
            error = "Файл requirements.txt не найден"
            return false
        }
        
        output.append("Установка зависимостей из \(requirementsFile.path)")
        
        let process = Process()
        process.executableURL = URL(fileURLWithPath: pythonPath)
        process.arguments = ["-m", "pip", "install", "-r", requirementsFile.path]
        
        let outputPipe = Pipe()
        let errorPipe = Pipe()
        process.standardOutput = outputPipe
        process.standardError = errorPipe
        
        do {
            try process.run()
            process.waitUntilExit()
            
            if process.terminationStatus == 0 {
                output.append("Зависимости успешно установлены")
                return true
            } else {
                let errorData = errorPipe.fileHandleForReading.readDataToEndOfFile()
                if let errorString = String(data: errorData, encoding: .utf8) {
                    error = "Ошибка установки зависимостей: \(errorString)"
                }
                return false
            }
        } catch {
            self.error = "Ошибка запуска pip: \(error.localizedDescription)"
            return false
        }
    }
    
    func checkPythonVersion() -> String? {
        let process = Process()
        let outputPipe = Pipe()
        
        process.executableURL = URL(fileURLWithPath: pythonPath)
        process.arguments = ["--version"]
        process.standardOutput = outputPipe
        
        do {
            try process.run()
            process.waitUntilExit()
            
            let outputData = outputPipe.fileHandleForReading.readDataToEndOfFile()
            return String(data: outputData, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
        } catch {
            return nil
        }
    }
    
    func getInstalledPackages() -> [String] {
        let process = Process()
        let outputPipe = Pipe()
        
        process.executableURL = URL(fileURLWithPath: pythonPath)
        process.arguments = ["-m", "pip", "list", "--format=freeze"]
        process.standardOutput = outputPipe
        
        do {
            try process.run()
            process.waitUntilExit()
            
            let outputData = outputPipe.fileHandleForReading.readDataToEndOfFile()
            guard let outputString = String(data: outputData, encoding: .utf8) else {
                return []
            }
            
            return outputString.components(separatedBy: "\n").filter { !$0.isEmpty }
        } catch {
            return []
        }
    }
}

extension PythonService {
    func runFastAPIServer(port: Int = 8000) {
        let serverScript = """
import asyncio
import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Optional
from pydantic import BaseModel
import json
import os

app = FastAPI(title="Telegram Deposit Scanner API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Account(BaseModel):
    id: str
    name: str
    phone: str
    api_id: str
    api_hash: str
    is_active: bool

class Deposit(BaseModel):
    uid: str
    amount: float
    currency: str = "USD"
    timestamp: str
    country: Optional[str] = None
    account_id: str

class ScanRequest(BaseModel):
    account_ids: List[str]
    uids: List[str]
    min_deposit: float = 14.0

class ScanResponse(BaseModel):
    success: bool
    deposits: List[Deposit]
    error: Optional[str] = None

# Мок данные для демонстрации
mock_accounts = [
    Account(
        id="1",
        name="Эвелин",
        phone="+79891243575",
        api_id="38902122",
        api_hash="d2bf17a44846878618e6eb15e9cce56d",
        is_active=True
    ),
    Account(
        id="2",
        name="Саймон",
        phone="+79128072453",
        api_id="25835050",
        api_hash="854c2bc7f1c8fa0fda69e171e356b6b2",
        is_active=True
    ),
    Account(
        id="3",
        name="Фади",
        phone="+79878547363",
        api_id="34438704",
        api_hash="fc6277c6c44927f132a16fd9f86d3cc6",
        is_active=True
    )
]

@app.get("/")
async def root():
    return {"message": "Telegram Deposit Scanner API", "status": "running"}

@app.get("/accounts", response_model=List[Account])
async def get_accounts():
    return mock_accounts

@app.post("/scan", response_model=ScanResponse)
async def scan_deposits(request: ScanRequest):
    try:
        # Имитация сканирования
        deposits = []
        for uid in request.uids:
            for account_id in request.account_ids:
                # Случайные данные для демонстрации
                import random
                from datetime import datetime
                
                amount = random.uniform(20, 1000)
                if amount >= request.min_deposit:
                    deposit = Deposit(
                        uid=uid,
                        amount=round(amount, 2),
                        timestamp=datetime.now().isoformat(),
                        country=random.choice(["Russia", "Nigeria", "USA", "China", "India"]),
                        account_id=account_id
                    )
                    deposits.append(deposit)
        
        return ScanResponse(success=True, deposits=deposits)
        
    except Exception as e:
        return ScanResponse(success=False, deposits=[], error=str(e))

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": "\(datetime.now().isoformat())"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=\(port))
"""
        
        let tempDir = FileManager.default.temporaryDirectory
        let scriptURL = tempDir.appendingPathComponent("fastapi_server.py")
        
        do {
            try serverScript.write(to: scriptURL, atomically: true, encoding: .utf8)
            runScript(at: scriptURL.path)
        } catch {
            self.error = "Ошибка создания скрипта сервера: \(error.localizedDescription)"
        }
    }
}
