import Foundation
import Combine

struct APIError: Error, LocalizedError {
    let message: String
    
    var errorDescription: String? {
        return message
    }
}

class APIService: ObservableObject {
    @Published var isConnected: Bool = false
    @Published var lastError: String?
    
    private var baseURL: String = "http://localhost:8000"
    private var session: URLSession
    
    init(baseURL: String = "http://localhost:8000") {
        self.baseURL = baseURL
        self.session = URLSession(configuration: .default)
        checkConnection()
    }
    
    func checkConnection() {
        guard let url = URL(string: "\(baseURL)/health") else {
            lastError = "Неверный URL"
            isConnected = false
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 5
        
        let task = session.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    self?.lastError = error.localizedDescription
                    self?.isConnected = false
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse else {
                    self?.lastError = "Некорректный ответ сервера"
                    self?.isConnected = false
                    return
                }
                
                if (200...299).contains(httpResponse.statusCode) {
                    self?.isConnected = true
                    self?.lastError = nil
                } else {
                    self?.lastError = "Ошибка сервера: \(httpResponse.statusCode)"
                    self?.isConnected = false
                }
            }
        }
        
        task.resume()
    }
    
    func fetchAccounts() -> AnyPublisher<[TelegramAccount], Error> {
        guard let url = URL(string: "\(baseURL)/accounts") else {
            return Fail(error: APIError(message: "Неверный URL"))
                .eraseToAnyPublisher()
        }
        
        return session.dataTaskPublisher(for: url)
            .tryMap { data, response in
                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode) else {
                    throw APIError(message: "Ошибка сервера")
                }
                return data
            }
            .decode(type: [APITelegramAccount].self, decoder: JSONDecoder())
            .map { apiAccounts in
                apiAccounts.map { apiAccount in
                    TelegramAccount(
                        id: UUID(uuidString: apiAccount.id) ?? UUID(),
                        name: apiAccount.name,
                        phoneNumber: apiAccount.phone,
                        apiID: apiAccount.api_id,
                        apiHash: apiAccount.api_hash,
                        isActive: apiAccount.is_active,
                        lastSeen: Date()
                    )
                }
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
    
    func scanDeposits(accountIDs: [UUID], uids: [String], minDeposit: Double) -> AnyPublisher<[Deposit], Error> {
        guard let url = URL(string: "\(baseURL)/scan") else {
            return Fail(error: APIError(message: "Неверный URL"))
                .eraseToAnyPublisher()
        }
        
        let requestBody = APIScanRequest(
            account_ids: accountIDs.map { $0.uuidString },
            uids: uids,
            min_deposit: minDeposit
        )
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            request.httpBody = try JSONEncoder().encode(requestBody)
        } catch {
            return Fail(error: error)
                .eraseToAnyPublisher()
        }
        
        return session.dataTaskPublisher(for: request)
            .tryMap { data, response in
                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode) else {
                    throw APIError(message: "Ошибка сервера")
                }
                return data
            }
            .decode(type: APIScanResponse.self, decoder: JSONDecoder())
            .tryMap { response in
                if response.success {
                    return response.deposits.map { apiDeposit in
                        Deposit(
                            id: UUID(),
                            uid: apiDeposit.uid,
                            amount: apiDeposit.amount,
                            currency: apiDeposit.currency,
                            date: ISO8601DateFormatter().date(from: apiDeposit.timestamp) ?? Date(),
                            country: apiDeposit.country ?? "",
                            accountID: UUID(uuidString: apiDeposit.account_id) ?? UUID(),
                            accountName: "" // Будет заполнено позже
                        )
                    }
                } else {
                    throw APIError(message: response.error ?? "Неизвестная ошибка")
                }
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
    
    func testConnection() -> AnyPublisher<String, Error> {
        guard let url = URL(string: "\(baseURL)/") else {
            return Fail(error: APIError(message: "Неверный URL"))
                .eraseToAnyPublisher()
        }
        
        return session.dataTaskPublisher(for: url)
            .tryMap { data, response in
                guard let httpResponse = response as? HTTPURLResponse else {
                    throw APIError(message: "Некорректный ответ")
                }
                
                if (200...299).contains(httpResponse.statusCode) {
                    if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                       let message = json["message"] as? String {
                        return message
                    }
                    return "Подключено успешно"
                } else {
                    throw APIError(message: "Ошибка: \(httpResponse.statusCode)")
                }
            }
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}

// Модели для API
private struct APITelegramAccount: Codable {
    let id: String
    let name: String
    let phone: String
    let api_id: String
    let api_hash: String
    let is_active: Bool
}

private struct APIScanRequest: Codable {
    let account_ids: [String]
    let uids: [String]
    let min_deposit: Double
}

private struct APIScanResponse: Codable {
    let success: Bool
    let deposits: [APIDeposit]
    let error: String?
}

private struct APIDeposit: Codable {
    let uid: String
    let amount: Double
    let currency: String
    let timestamp: String
    let country: String?
    let account_id: String
}
