import SwiftUI

struct ContentView: View {
    @StateObject private var appState = AppState()
    @State private var selection: NavigationItem? = .dashboard
    
    enum NavigationItem: String, CaseIterable {
        case dashboard = "Дашборд"
        case accounts = "Аккаунты"
        case scanner = "Сканер"
        case deposits = "Депозиты"
        case pythonLogs = "Логи Python"
        case settings = "Настройки"
        
        var icon: String {
            switch self {
            case .dashboard: return "chart.bar.fill"
            case .accounts: return "person.2.fill"
            case .scanner: return "magnifyingglass"
            case .deposits: return "dollarsign.circle.fill"
            case .pythonLogs: return "terminal.fill"
            case .settings: return "gear"
            }
        }
    }
    
    var body: some View {
        NavigationView {
            SidebarView(selection: $selection, appState: appState)
            
            MainContentView(appState: appState)
                .frame(minWidth: 600, minHeight: 400)
            
            DetailView(appState: appState)
                .frame(minWidth: 300, maxWidth: 400, minHeight: 400)
        }
        .navigationTitle("Telegram Deposit Scanner")
    }
}

struct SidebarView: View {
    @Binding var selection: ContentView.NavigationItem?
    @ObservedObject var appState: AppState
    
    var body: some View {
        List(selection: $selection) {
            ForEach(ContentView.NavigationItem.allCases, id: \.self) { item in
                NavigationLink(
                    destination: EmptyView(),
                    tag: item,
                    selection: $selection
                ) {
                    Label(item.rawValue, systemImage: item.icon)
                        .foregroundColor(selection == item ? .accentColor : .primary)
                }
                .padding(.vertical, 4)
            }
        }
        .listStyle(SidebarListStyle())
        .frame(minWidth: 200)
        .toolbar {
            ToolbarItem {
                Button(action: toggleSidebar) {
                    Image(systemName: "sidebar.left")
                }
            }
        }
    }
    
    private func toggleSidebar() {
        NSApp.keyWindow?.firstResponder?
            .tryToPerform(#selector(NSSplitViewController.toggleSidebar(_:)), with: nil)
    }
}

struct MainContentView: View {
    @ObservedObject var appState: AppState
    
    var body: some View {
        VStack(spacing: 0) {
            HeaderView(appState: appState)
            
            if let selection = (NSApp.delegate as? AppDelegate)?.selectedView {
                switch selection {
                case .dashboard:
                    DashboardView(appState: appState)
                case .accounts:
                    AccountsView(appState: appState)
                case .scanner:
                    ScannerView(appState: appState)
                case .deposits:
                    DepositsView(appState: appState)
                case .pythonLogs:
                    PythonOutputView()
                        .environmentObject(appState)
                case .settings:
                    SettingsView()
                        .environmentObject(appState)
                }
            } else {
                DashboardView(appState: appState)
            }
        }
    }
}

struct HeaderView: View {
    @ObservedObject var appState: AppState
    
    var body: some View {
        HStack {
            Text("Telegram Deposit Scanner")
                .font(.title2)
                .fontWeight(.bold)
                .foregroundLinearGradient(colors: [.blue, .purple])
            
            Spacer()
            
            ScanControlButton(appState: appState)
            
            Button(action: appState.saveCSVToDesktop) {
                Label("Экспорт", systemImage: "square.and.arrow.up")
            }
            .buttonStyle(GlassButtonStyle(iconColor: .green))
            .disabled(appState.deposits.isEmpty)
            
            Button(action: appState.clearAllDeposits) {
                Label("Очистить", systemImage: "trash")
            }
            .buttonStyle(GlassButtonStyle(iconColor: .red))
            .disabled(appState.deposits.isEmpty)
        }
        .padding()
        .background(
            VisualEffectView(material: .headerView, blendingMode: .behindWindow)
        )
    }
}

struct ScanControlButton: View {
    @ObservedObject var appState: AppState
    
    var body: some View {
        Button(action: appState.startScan) {
            Label(
                appState.isScanning ? "Сканирование..." : "Начать сканирование",
                systemImage: appState.isScanning ? "stop.circle.fill" : "play.circle.fill"
            )
        }
        .buttonStyle(GlassButtonStyle(
            iconColor: appState.isScanning ? .orange : .blue,
            isActive: appState.isScanning
        ))
        .disabled(appState.isScanning)
        
        if appState.isScanning {
            ProgressView(value: appState.scanProgress)
                .progressViewStyle(LinearProgressViewStyle())
                .frame(width: 100)
        }
    }
}

struct DetailView: View {
    @ObservedObject var appState: AppState
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Статистика")
                .font(.headline)
                .foregroundLinearGradient(colors: [.blue, .purple])
            
            StatCardView(
                title: "Всего депозитов",
                value: "\(appState.scanStats.totalDeposits)",
                icon: "dollarsign.circle.fill",
                color: .green
            )
            
            StatCardView(
                title: "Общая сумма",
                value: String(format: "$%.2f", appState.scanStats.totalAmount),
                icon: "chart.bar.fill",
                color: .blue
            )
            
            StatCardView(
                title: "Средний депозит",
                value: String(format: "$%.2f", appState.scanStats.averageAmount),
                icon: "chart.pie.fill",
                color: .purple
            )
            
            StatCardView(
                title: "Всего сканирований",
                value: "\(appState.scanStats.totalScans)",
                icon: "magnifyingglass.circle.fill",
                color: .orange
            )
            
            Spacer()
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Активные аккаунты")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                ForEach(appState.accounts.prefix(3)) { account in
                    HStack {
                        Circle()
                            .fill(account.isActive ? Color.green : Color.gray)
                            .frame(width: 8, height: 8)
                        
                        Text(account.name)
                            .font(.caption)
                        
                        Spacer()
                        
                        Text(account.isActive ? "Активен" : "Неактивен")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                    }
                }
            }
            .padding()
            .background(Color.white.opacity(0.05))
            .cornerRadius(10)
        }
        .padding()
        .background(
            VisualEffectView(material: .sidebar, blendingMode: .behindWindow)
        )
    }
}

struct StatCardView: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(color)
            
            VStack(alignment: .leading) {
                Text(title)
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text(value)
                    .font(.title3)
                    .fontWeight(.bold)
            }
            
            Spacer()
        }
        .padding()
        .background(Color.white.opacity(0.05))
        .cornerRadius(10)
    }
}

struct VisualEffectView: NSViewRepresentable {
    let material: NSVisualEffectView.Material
    let blendingMode: NSVisualEffectView.BlendingMode
    
    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        view.material = material
        view.blendingMode = blendingMode
        view.state = .active
        return view
    }
    
    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {
        nsView.material = material
        nsView.blendingMode = blendingMode
    }
}

struct GlassButtonStyle: ButtonStyle {
    var iconColor: Color = .blue
    var isActive: Bool = false
    
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.callout)
            .foregroundColor(configuration.isPressed ? .white : .primary)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(
                Group {
                    if isActive {
                        LinearGradient(
                            colors: [iconColor.opacity(0.3), iconColor.opacity(0.1)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    } else {
                        Color.white.opacity(configuration.isPressed ? 0.2 : 0.1)
                    }
                }
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(iconColor.opacity(0.3), lineWidth: 1)
            )
            .cornerRadius(8)
            .scaleEffect(configuration.isPressed ? 0.98 : 1.0)
    }
}

extension View {
    func foregroundLinearGradient(colors: [Color]) -> some View {
        self.overlay(
            LinearGradient(
                colors: colors,
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        )
        .mask(self)
    }
}

class AppDelegate: NSObject, NSApplicationDelegate {
    @Published var selectedView: ContentView.NavigationItem? = .dashboard
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
