import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var appState: AppState
    @State private var selectedTab: SettingsTab = .general
    @State private var notificationsEnabled: Bool = true
    @State private var soundEnabled: Bool = true
    @State private var autoExportEnabled: Bool = false
    @State private var scanInterval: Double = 30
    @State private var minDepositAmount: Double = 14.0
    @State private var exportFormat: ExportFormat = .csv
    @State private var pythonPath: String = "/usr/bin/python3"
    @State private var apiPort: Int = 8000
    @State private var debugModeEnabled: Bool = false
    
    enum SettingsTab: String, CaseIterable {
        case general = "Общие"
        case accounts = "Аккаунты"
        case scanning = "Сканирование"
        case export = "Экспорт"
        case advanced = "Расширенные"
    }
    
    enum ExportFormat: String, CaseIterable {
        case csv = "CSV"
        case json = "JSON"
        case excel = "Excel"
    }
    
    var body: some View {
        VStack(spacing: 0) {
            TabHeaderView(selectedTab: $selectedTab)
            
            Divider()
                .background(Color.white.opacity(0.1))
            
            TabContentView(selectedTab: selectedTab)
                .padding()
            
            Divider()
                .background(Color.white.opacity(0.1))
            
            HStack {
                Button("Сбросить настройки") {
                    resetSettings()
                }
                .buttonStyle(GlassButtonStyle(iconColor: .orange))
                
                Spacer()
                
                Button("Сохранить") {
                    saveSettings()
                }
                .buttonStyle(GlassButtonStyle(iconColor: .blue))
            }
            .padding()
        }
        .background(
            VisualEffectView(material: .ultraThinMaterial, blendingMode: .behindWindow)
        )
        .frame(width: 600, height: 500)
    }
    
    private func resetSettings() {
        notificationsEnabled = true
        soundEnabled = true
        autoExportEnabled = false
        scanInterval = 30
        minDepositAmount = 14.0
        exportFormat = .csv
        pythonPath = "/usr/bin/python3"
        apiPort = 8000
        debugModeEnabled = false
        
        appState.addPythonLog("Настройки сброшены к значениям по умолчанию", level: .info)
    }
    
    private func saveSettings() {
        appState.settings.notificationsEnabled = notificationsEnabled
        appState.settings.soundEnabled = soundEnabled
        appState.settings.autoExportEnabled = autoExportEnabled
        appState.settings.scanIntervalMinutes = Int(scanInterval)
        appState.settings.minDepositAmount = minDepositAmount
        appState.settings.exportFormat = exportFormat.rawValue
        appState.settings.pythonPath = pythonPath
        appState.settings.apiPort = apiPort
        appState.settings.debugMode = debugModeEnabled
        
        appState.addPythonLog("Настройки сохранены", level: .success)
    }
}

struct TabHeaderView: View {
    @Binding var selectedTab: SettingsView.SettingsTab
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(SettingsView.SettingsTab.allCases, id: \.self) { tab in
                TabHeaderButton(
                    title: tab.rawValue,
                    isSelected: selectedTab == tab
                ) {
                    selectedTab = tab
                }
            }
        }
        .padding(.horizontal)
    }
}

struct TabHeaderButton: View {
    let title: String
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Text(title)
                    .font(.subheadline)
                    .fontWeight(isSelected ? .semibold : .regular)
                    .foregroundColor(isSelected ? .primary : .secondary)
                
                Rectangle()
                    .frame(height: 2)
                    .foregroundColor(isSelected ? .blue : .clear)
            }
            .padding(.vertical, 12)
            .padding(.horizontal, 16)
        }
        .buttonStyle(PlainButtonStyle())
        .background(isSelected ? Color.white.opacity(0.05) : Color.clear)
    }
}

struct TabContentView: View {
    let selectedTab: SettingsView.SettingsTab
    
    @EnvironmentObject var appState: AppState
    @State private var notificationsEnabled: Bool = true
    @State private var soundEnabled: Bool = true
    @State private var selectedTheme: String = "Системная"
    @State private var selectedLanguage: String = "Русский"
    @State private var autoExportEnabled: Bool = false
    @State private var scanInterval: Double = 30
    @State private var minDepositAmount: Double = 14.0
    @State private var exportFormat: SettingsView.ExportFormat = .csv
    @State private var exportPath: String = NSHomeDirectory() + "/Desktop"
    @State private var pythonPath: String = "/usr/bin/python3"
    @State private var apiPort: Int = 8000
    @State private var debugModeEnabled: Bool = false
    
    var body: some View {
        ScrollView {
            switch selectedTab {
            case .general:
                GeneralSettingsView(
                    notificationsEnabled: $notificationsEnabled,
                    soundEnabled: $soundEnabled,
                    selectedTheme: $selectedTheme,
                    selectedLanguage: $selectedLanguage
                )
            case .accounts:
                AccountsSettingsView(appState: appState)
            case .scanning:
                ScanningSettingsView(
                    scanInterval: $scanInterval,
                    minDepositAmount: $minDepositAmount,
                    autoExportEnabled: $autoExportEnabled
                )
            case .export:
                ExportSettingsView(
                    exportFormat: $exportFormat,
                    exportPath: $exportPath,
                    autoExportEnabled: $autoExportEnabled
                )
            case .advanced:
                AdvancedSettingsView(
                    pythonPath: $pythonPath,
                    apiPort: $apiPort,
                    debugModeEnabled: $debugModeEnabled
                )
            }
        }
    }
}

struct GeneralSettingsView: View {
    @Binding var notificationsEnabled: Bool
    @Binding var soundEnabled: Bool
    @Binding var selectedTheme: String
    @Binding var selectedLanguage: String
    
    let themes = ["Системная", "Светлая", "Темная"]
    let languages = ["Русский", "English", "中文"]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            SettingsSection(title: "Внешний вид") {
                SettingsRow(title: "Тема") {
                    Picker("", selection: $selectedTheme) {
                        ForEach(themes, id: \.self) { theme in
                            Text(theme).tag(theme)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .frame(width: 300)
                }
                
                SettingsRow(title: "Язык") {
                    Picker("", selection: $selectedLanguage) {
                        ForEach(languages, id: \.self) { language in
                            Text(language).tag(language)
                        }
                    }
                    .frame(width: 200)
                }
            }
            
            SettingsSection(title: "Уведомления") {
                SettingsRow(title: "Показывать уведомления") {
                    Toggle("", isOn: $notificationsEnabled)
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                SettingsRow(title: "Звуковые оповещения") {
                    Toggle("", isOn: $soundEnabled)
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
            }
        }
    }
}

struct AccountsSettingsView: View {
    @ObservedObject var appState: AppState
    @State private var showingAddAccount = false
    @State private var newAccountName = ""
    @State private var newAccountPhone = ""
    @State private var newAccountAPIID = ""
    @State private var newAccountAPIHash = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            SettingsSection(title: "Управление аккаунтами") {
                ForEach(appState.accounts) { account in
                    AccountRowView(account: account, appState: appState)
                }
                
                Button(action: { showingAddAccount = true }) {
                    Label("Добавить аккаунт", systemImage: "plus.circle")
                }
                .buttonStyle(GlassButtonStyle(iconColor: .green))
                .padding(.top, 8)
            }
            
            SettingsSection(title: "Безопасность") {
                SettingsRow(title: "Шифровать session файлы") {
                    Toggle("", isOn: .constant(true))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                SettingsRow(title: "Требовать пароль при запуске") {
                    Toggle("", isOn: .constant(false))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                Button("Настроить 2FA") {
                    // 2FA настройки
                }
                .buttonStyle(GlassButtonStyle(iconColor: .blue))
                .font(.caption)
            }
        }
        .sheet(isPresented: $showingAddAccount) {
            AddAccountView(
                isPresented: $showingAddAccount,
                name: $newAccountName,
                phone: $newAccountPhone,
                apiID: $newAccountAPIID,
                apiHash: $newAccountAPIHash
            ) {
                let newAccount = TelegramAccount(
                    id: UUID(),
                    name: newAccountName,
                    phoneNumber: newAccountPhone,
                    apiID: newAccountAPIID,
                    apiHash: newAccountAPIHash,
                    isActive: true,
                    lastSeen: Date()
                )
                appState.accounts.append(newAccount)
                appState.saveAccounts()
                
                newAccountName = ""
                newAccountPhone = ""
                newAccountAPIID = ""
                newAccountAPIHash = ""
            }
        }
    }
}

struct AccountRowView: View {
    let account: TelegramAccount
    @ObservedObject var appState: AppState
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(account.name)
                    .font(.headline)
                Text(account.phoneNumber)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Toggle("", isOn: Binding(
                get: { account.isActive },
                set: { newValue in
                    if let index = appState.accounts.firstIndex(where: { $0.id == account.id }) {
                        appState.accounts[index].isActive = newValue
                        appState.saveAccounts()
                    }
                }
            ))
            .toggleStyle(SwitchToggleStyle(tint: .blue))
            
            Button(action: { deleteAccount(account) }) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 12)
        .background(Color.white.opacity(0.03))
        .cornerRadius(8)
    }
    
    private func deleteAccount(_ account: TelegramAccount) {
        appState.accounts.removeAll { $0.id == account.id }
        appState.saveAccounts()
    }
}

struct AddAccountView: View {
    @Binding var isPresented: Bool
    @Binding var name: String
    @Binding var phone: String
    @Binding var apiID: String
    @Binding var apiHash: String
    let onAdd: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Добавить аккаунт Telegram")
                .font(.title2)
                .fontWeight(.bold)
            
            Form {
                TextField("Имя аккаунта", text: $name)
                TextField("Номер телефона", text: $phone)
                TextField("API ID", text: $apiID)
                SecureField("API Hash", text: $apiHash)
            }
            .padding()
            
            HStack {
                Button("Отмена") {
                    isPresented = false
                }
                .buttonStyle(GlassButtonStyle(iconColor: .gray))
                
                Spacer()
                
                Button("Добавить") {
                    onAdd()
                    isPresented = false
                }
                .buttonStyle(GlassButtonStyle(iconColor: .blue))
                .disabled(name.isEmpty || phone.isEmpty || apiID.isEmpty || apiHash.isEmpty)
            }
            .padding()
        }
        .padding()
        .frame(width: 400)
        .background(
            VisualEffectView(material: .ultraThinMaterial, blendingMode: .behindWindow)
        )
    }
}

struct ScanningSettingsView: View {
    @Binding var scanInterval: Double
    @Binding var minDepositAmount: Double
    @Binding var autoExportEnabled: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            SettingsSection(title: "Параметры сканирования") {
                SettingsRow(title: "Интервал сканирования (минуты)") {
                    VStack {
                        Slider(value: $scanInterval, in: 1...120, step: 1)
                        Text("\(Int(scanInterval)) минут")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .frame(width: 300)
                }
                
                SettingsRow(title: "Минимальный депозит ($)") {
                    HStack {
                        Slider(value: $minDepositAmount, in: 1...1000, step: 1)
                        Text("$\(Int(minDepositAmount))")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .frame(width: 300)
                }
            }
            
            SettingsSection(title: "Автоматизация") {
                SettingsRow(title: "Автосканирование") {
                    Toggle("", isOn: .constant(true))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                SettingsRow(title: "Автоэкспорт результатов") {
                    Toggle("", isOn: $autoExportEnabled)
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                SettingsRow(title: "Расписание") {
                    DatePicker("", selection: .constant(Date()))
                        .labelsHidden()
                }
            }
        }
    }
}

struct ExportSettingsView: View {
    @Binding var exportFormat: SettingsView.ExportFormat
    @Binding var exportPath: String
    @Binding var autoExportEnabled: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            SettingsSection(title: "Форматы экспорта") {
                SettingsRow(title: "Формат файла") {
                    Picker("", selection: $exportFormat) {
                        ForEach(SettingsView.ExportFormat.allCases, id: \.self) { format in
                            Text(format.rawValue).tag(format)
                        }
                    }
                    .frame(width: 200)
                }
                
                SettingsRow(title: "Включать заголовки") {
                    Toggle("", isOn: .constant(true))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                SettingsRow(title: "Включать временные метки") {
                    Toggle("", isOn: .constant(true))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
            }
            
            SettingsSection(title: "Директории") {
                SettingsRow(title: "Папка для экспорта") {
                    HStack {
                        TextField("", text: $exportPath)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .frame(width: 300)
                        
                        Button("Обзор...") {
                            selectExportDirectory()
                        }
                        .buttonStyle(GlassButtonStyle(iconColor: .blue))
                    }
                }
                
                SettingsRow(title: "Автоочистка старых файлов") {
                    Toggle("", isOn: .constant(false))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
            }
        }
    }
    
    private func selectExportDirectory() {
        let panel = NSOpenPanel()
        panel.title = "Выберите папку для экспорта"
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        
        panel.begin { response in
            if response == .OK, let url = panel.url {
                exportPath = url.path
            }
        }
    }
}

struct AdvancedSettingsView: View {
    @Binding var pythonPath: String
    @Binding var apiPort: Int
    @Binding var debugModeEnabled: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            SettingsSection(title: "Python настройки") {
                SettingsRow(title: "Путь к Python") {
                    TextField("", text: $pythonPath)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(width: 300)
                }
                
                SettingsRow(title: "Автоустановка зависимостей") {
                    Toggle("", isOn: .constant(true))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                Button("Проверить установку Python") {
                    checkPythonInstallation()
                }
                .buttonStyle(GlassButtonStyle(iconColor: .blue))
                .font(.caption)
            }
            
            SettingsSection(title: "API настройки") {
                SettingsRow(title: "Порт API сервера") {
                    TextField("", value: $apiPort, format: .number)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(width: 100)
                }
                
                SettingsRow(title: "Автозапуск сервера") {
                    Toggle("", isOn: .constant(true))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
            }
            
            SettingsSection(title: "Отладка") {
                SettingsRow(title: "Режим отладки") {
                    Toggle("", isOn: $debugModeEnabled)
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                SettingsRow(title: "Детальное логирование") {
                    Toggle("", isOn: .constant(false))
                        .toggleStyle(SwitchToggleStyle(tint: .blue))
                }
                
                Button("Показать логи приложения") {
                    // Показать логи
                }
                .buttonStyle(GlassButtonStyle(iconColor: .orange))
                .font(.caption)
            }
        }
    }
    
    private func checkPythonInstallation() {
        // Проверка установки Python
    }
}

struct SettingsSection<Content: View>: View {
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
                .foregroundLinearGradient(colors: [.blue, .purple])
                .padding(.bottom, 4)
            
            content
        }
        .padding()
        .background(Color.white.opacity(0.03))
        .cornerRadius(12)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.white.opacity(0.1), lineWidth: 1)
        )
    }
}

struct SettingsRow<Content: View>: View {
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        HStack {
            Text(title)
                .font(.subheadline)
                .frame(width: 200, alignment: .leading)
            
            Spacer()
            
            content
        }
        .padding(.vertical, 4)
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .environmentObject(AppState())
    }
}
