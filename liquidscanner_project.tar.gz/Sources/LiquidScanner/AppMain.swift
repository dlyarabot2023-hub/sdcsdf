import SwiftUI

@main
struct LiquidScannerApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .frame(minWidth: 1000, minHeight: 600)
        }
        .windowStyle(HiddenTitleBarWindowStyle())
        .commands {
            CommandGroup(replacing: .newItem) { }
            CommandGroup(replacing: .help) {
                Button("Документация") {
                    NSWorkspace.shared.open(URL(string: "https://github.com")!)
                }
            }
        }
        
        Settings {
            SettingsView()
                .frame(width: 600, height: 500)
        }
    }
}
