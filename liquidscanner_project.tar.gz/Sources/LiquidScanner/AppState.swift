import Foundation
import Combine
import SwiftUI

class AppState: ObservableObject {
    @Published var accounts: [TelegramAccount] = [
        TelegramAccount(name: "Эвелин", phoneNumber: "+79891243575", apiID: "38902122", apiHash: "d2bf17a44846878618e6eb15e9cce56d"),
        TelegramAccount(name: "Саймон", phoneNumber: "+79128072453", apiID: "25835050", apiHash: "854c2bc7f1c8fa0fda69e171e356b6b2"),
        TelegramAccount(name: "Фади", phoneNumber: "+79878547363", apiID: "34438704", apiHash: "fc6277c6c44927f132a16fd9f86d3cc6")
    ]
    
    @Published var deposits: [Deposit] = []
    @Published var scanSettings = ScanSettings()
    @Published var scanStats = ScanStats()
    @Published var isScanning: Bool = false
    @Published var scanProgress: Double = 0.0
    @Published var pythonLogs: [PythonOutput] = []
    
    func saveAccounts() {
        print("Accounts saved: \(accounts.count)")
    }
    
    func toggleAccount(_ account: TelegramAccount) {
        if let index = accounts.firstIndex(where: { $0.id == account.id }) {
            accounts[index].isActive.toggle()
            saveAccounts()
        }
    }
    
    func startScan() {
        isScanning = true
        scanProgress = 0.0
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.scanProgress = 0.2
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            self.scanProgress = 0.5
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            self.scanProgress = 0.8
            self.addTestDeposits()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.scanProgress = 1.0
            self.isScanning = false
            
            self.scanStats.totalScans += 1
            self.scanStats.totalDeposits = self.deposits.count
            self.scanStats.totalAmount = self.deposits.reduce(0) { $0 + $1.amount }
            self.scanStats.lastScanDate = Date()
        }
    }
    
    private func addTestDeposits() {
        let testDeposits = [
            Deposit(uid: "103047126", amount: 727.56, country: "Nigeria", accountID: accounts[0].id, accountName: accounts[0].name),
            Deposit(uid: "205184392", amount: 350.20, country: "USA", accountID: accounts[1].id, accountName: accounts[1].name),
            Deposit(uid: "309275641", amount: 120.75, country: "Russia", accountID: accounts[2].id, accountName: accounts[2].name),
            Deposit(uid: "401938475", amount: 950.00, country: "China", accountID: accounts[0].id, accountName: accounts[0].name),
            Deposit(uid: "502746183", amount: 45.30, country: "India", accountID: accounts[1].id, accountName: accounts[1].name)
        ]
        
        deposits.append(contentsOf: testDeposits)
    }
    
    func addPythonLog(_ message: String, level: PythonOutput.LogLevel = .info) {
        let log = PythonOutput(message: message, level: level)
        pythonLogs.append(log)
        
        if pythonLogs.count > 1000 {
            pythonLogs.removeFirst()
        }
    }
    
    func clearPythonLogs() {
        pythonLogs.removeAll()
    }
    
    func exportToCSV() -> String {
        var csv = "UID,Amount,Currency,Date,Country,Account\n"
        
        for deposit in deposits {
            let dateString = ISO8601DateFormatter().string(from: deposit.date)
            csv += "\"\(deposit.uid)\",\(deposit.amount),\(deposit.currency),\"\(dateString)\",\"\(deposit.country)\",\"\(deposit.accountName)\"\n"
        }
        
        return csv
    }
    
    func saveCSVToDesktop() {
        let csvContent = exportToCSV()
        let desktopPath = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first!
        let fileURL = desktopPath.appendingPathComponent("deposits_\(Date().timeIntervalSince1970).csv")
        
        do {
            try csvContent.write(to: fileURL, atomically: true, encoding: .utf8)
            addPythonLog("Файл сохранен: \(fileURL.lastPathComponent)", level: .success)
        } catch {
            addPythonLog("Ошибка сохранения: \(error.localizedDescription)", level: .error)
        }
    }
    
    func clearAllDeposits() {
        deposits.removeAll()
        scanStats.totalDeposits = 0
        scanStats.totalAmount = 0.0
        addPythonLog("Все депозиты очищены", level: .info)
    }
}
