import SwiftUI

struct DashboardView: View {
    @ObservedObject var appState: AppState
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Статистические карточки
                StatsGridView(appState: appState)
                    .padding(.horizontal, 30)
                
                // Последние депозиты
                RecentDepositsView(appState: appState)
                    .padding(.horizontal, 30)
                
                Spacer()
            }
            .padding(.top, 20)
        }
    }
}

struct StatsGridView: View {
    @ObservedObject var appState: AppState
    
    var body: some View {
        HStack(spacing: 16) {
            StatCard(
                icon: "dollarsign.circle.fill",
                title: "Общая сумма",
                value: appState.stats.formattedTotalAmount,
                color: .green,
                trend: .up
            )
            
            StatCard(
                icon: "number.circle.fill",
                title: "Всего депозитов",
                value: "\(appState.stats.totalFound)",
                color: .blue,
                trend: .up
            )
            
            StatCard(
                icon: "chart.bar.fill",
                title: "Средний депозит",
                value: appState.stats.formattedAverageAmount,
                color: .purple,
                trend: .neutral
            )
            
            StatCard(
                icon: "clock.fill",
                title: "Время работы",
                value: formatTimeInterval(appState.stats.elapsedTime),
                color: .orange,
                trend: .up
            )
        }
    }
}

struct StatCard: View {
    let icon: String
    let title: String
    let value: String
    let color: Color
    let trend: Trend
    
    enum Trend {
        case up, down, neutral
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: icon)
                    .font(.title2)
                    .foregroundColor(color)
                
                Spacer()
                
                if trend != .neutral {
                    Image(systemName: trend == .up ? "arrow.up.right" : "arrow.down.right")
                        .font(.caption)
                        .foregroundColor(trend == .up ? .green : .red)
                }
            }
            
            Text(value)
                .font(.title2)
                .fontWeight(.bold)
                .foregroundColor(.primary)
            
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}

struct RecentDepositsView: View {
    @ObservedObject var appState: AppState
    
    var recentDeposits: [Deposit] {
        Array(appState.deposits.suffix(5).reversed())
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Последние депозиты")
                    .font(.headline)
                
                Spacer()
                
                if !recentDeposits.isEmpty {
                    Button("Все") {
                        appState.selectedTab = 3
                    }
                    .font(.caption)
                }
            }
            
            if recentDeposits.isEmpty {
                EmptyStateView()
            } else {
                VStack(spacing: 12) {
                    ForEach(recentDeposits) { deposit in
                        DepositRowView(deposit: deposit)
                    }
                }
            }
        }
        .padding()
        .background(.ultraThinMaterial)
        .cornerRadius(16)
    }
}

struct DepositRowView: View {
    let deposit: Deposit
    
    var body: some View {
        HStack(spacing: 16) {
            // Аватар страны
            Text(countryFlag(deposit.country))
                .font(.title2)
            
            // Информация
            VStack(alignment: .leading, spacing: 4) {
                Text("UID: \(deposit.uid)")
                    .font(.system(.body, design: .monospaced))
                    .fontWeight(.medium)
                
                HStack {
                    Text(deposit.country)
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    Text("•")
                        .foregroundColor(.secondary)
                    
                    Text(deposit.accountName)
                        .font(.caption)
                        .foregroundColor(.blue)
                }
            }
            
            Spacer()
            
            // Сумма
            VStack(alignment: .trailing, spacing: 4) {
                Text(deposit.formattedAmount)
                    .font(.headline)
                    .foregroundColor(.green)
                
                Text("\(deposit.count) деп.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .background(.ultraThinMaterial)
        .opacity(0.5)
        .cornerRadius(12)
    }
    
    private func countryFlag(_ country: String) -> String {
        let flags: [String: String] = [
            "Nigeria": "🇳🇬",
            "USA": "🇺🇸",
            "UK": "🇬🇧",
            "Germany": "🇩🇪",
            "France": "🇫🇷",
            "Brazil": "🇧🇷",
            "Russia": "🇷🇺",
            "China": "🇨🇳",
            "India": "🇮🇳"
        ]
        return flags[country] ?? "🌐"
    }
}

struct EmptyStateView: View {
    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 48))
                .foregroundColor(.secondary)
                .opacity(0.5)
            
            VStack(spacing: 8) {
                Text("Депозиты не найдены")
                    .font(.headline)
                
                Text("Запустите сканирование для поиска депозитов")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
        }
        .frame(maxWidth: .infinity)
        .padding(40)
    }
}
