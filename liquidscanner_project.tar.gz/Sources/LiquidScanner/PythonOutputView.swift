import SwiftUI

struct PythonOutputView: View {
    @EnvironmentObject var appState: AppState
    @State private var searchText: String = ""
    @State private var selectedLogLevel: PythonOutput.LogLevel = .all
    @State private var autoScrollEnabled: Bool = true
    
    // ДОБАВЬТЕ ЭТУ ВЫЧИСЛЯЕМУЮ ПЕРЕМЕННУЮ ДЛЯ ДОСТУПА К published-свойству
    private var logs: [PythonOutput] {
        return appState.pythonLogs // Теперь доступ через вычисляемое свойство
    }
    
    var filteredLogs: [PythonOutput] {
        logs.filter { log in // Используем локальную переменную logs
            let matchesLevel = selectedLogLevel == .all || log.level == selectedLogLevel
            let matchesSearch = searchText.isEmpty ||
                log.message.localizedCaseInsensitiveContains(searchText)
            return matchesLevel && matchesSearch
        }
    }
    
    // ОСТАЛЬНОЙ КОД ФАЙЛА БЕЗ ИЗМЕНЕНИЙ...
    // ... (весь остальной код остается точно таким же, как в предыдущей версии)
    
    private func addSampleLogs() {
        let sampleLogs = [
            ("Запуск Python сервиса...", PythonOutput.LogLevel.info),
            ("Проверка зависимостей...", PythonOutput.LogLevel.info),
            ("FastAPI сервер запущен на порту 8000", PythonOutput.LogLevel.success),
            ("Подключение к аккаунту Эвелин...", PythonOutput.LogLevel.info),
            ("Успешная авторизация в Telegram", PythonOutput.LogLevel.success),
            ("Сканирование UID: 103047126", PythonOutput.LogLevel.info),
            ("Найден депозит: $50.00", PythonOutput.LogLevel.success),
            ("Ошибка подключения к прокси", PythonOutput.LogLevel.error),
            ("Переподключение через 5 секунд...", PythonOutput.LogLevel.warning),
            ("Сканирование завершено, найдено 15 депозитов", PythonOutput.LogLevel.success)
        ]
        
        sampleLogs.forEach { message, level in
            appState.addPythonLog(message, level: level)
        }
    }
}

// ВСЕ ОСТАЛЬНЫЕ СТРУКТУРЫ ИЗ ФАЙЛА...
// ... (LogEntryView, LogLevelPicker и т.д. остаются без изменений)

struct PythonOutputView_Previews: PreviewProvider {
    static var previews: some View {
        PythonOutputView()
            .environmentObject(AppState())
            .frame(width: 400, height: 500)
    }
}
