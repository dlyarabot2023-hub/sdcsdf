import Foundation
import SwiftUI
import Combine

struct TelegramAccount: Identifiable, Codable {
    let id: UUID
    var name: String
    var phoneNumber: String
    var apiID: String
    var apiHash: String
    var isActive: Bool
    var lastSeen: Date
    
    init(id: UUID = UUID(), name: String, phoneNumber: String, apiID: String, apiHash: String, isActive: Bool = true, lastSeen: Date = Date()) {
        self.id = id
        self.name = name
        self.phoneNumber = phoneNumber
        self.apiID = apiID
        self.apiHash = apiHash
        self.isActive = isActive
        self.lastSeen = lastSeen
    }
}

struct Deposit: Identifiable, Codable {
    let id: UUID
    let uid: String
    let amount: Double
    let currency: String
    let date: Date
    let country: String
    let accountID: UUID
    let accountName: String
    
    init(id: UUID = UUID(), uid: String, amount: Double, currency: String = "USD", date: Date = Date(), country: String = "", accountID: UUID, accountName: String = "") {
        self.id = id
        self.uid = uid
        self.amount = amount
        self.currency = currency
        self.date = date
        self.country = country
        self.accountID = accountID
        self.accountName = accountName
    }
}

struct ScanSettings: Codable {
    var notificationsEnabled: Bool = true
    var soundEnabled: Bool = true
    var autoExportEnabled: Bool = false
    var scanIntervalMinutes: Int = 30
    var minDepositAmount: Double = 14.0
    var exportFormat: String = "csv"
    var pythonPath: String = "/usr/bin/python3"
    var apiPort: Int = 8000
    var debugMode: Bool = false
}

struct ScanStats: Codable {
    var totalScans: Int = 0
    var totalDeposits: Int = 0
    var totalAmount: Double = 0.0
    var lastScanDate: Date?
    
    var averageAmount: Double {
        return totalDeposits > 0 ? totalAmount / Double(totalDeposits) : 0.0
    }
}

struct PythonOutput: Identifiable {
    let id: UUID
    let message: String
    let timestamp: Date
    let level: LogLevel
    
    init(id: UUID = UUID(), message: String, timestamp: Date = Date(), level: LogLevel = .info) {
        self.id = id
        self.message = message
        self.timestamp = timestamp
        self.level = level
    }
    
    enum LogLevel: String, CaseIterable {
        case info = "info"
        case success = "success"
        case warning = "warning"
        case error = "error"
        case all = "all"
    }
    
    var fullDescription: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "HH:mm:ss"
        return "[\(formatter.string(from: timestamp))] [\(level.rawValue.uppercased())] \(message)"
    }
}
