// swift-tools-version:5.7
import PackageDescription

let package = Package(
    name: "LiquidScanner",
    platforms: [.macOS(.v12)],
    products: [
        .executable(name: "LiquidScanner", targets: ["LiquidScanner"])
    ],
    targets: [
        .executableTarget(
            name: "LiquidScanner",
            dependencies: [],
            path: "Sources/LiquidScanner",
            resources: [.process("Resources")]
        )
    ]
)
